# v8 device tests — not yet performed

1. Android: tap JSON backup export twice rapidly; only one system save dialog should be active.
2. Android: cancel the picker, then export again; the next picker should open.
3. Android: save a backup, open the saved JSON in Files, verify it contains the expected test data; do not infer success solely from a toast.
4. Android: force a failed destination write, verify failure and ability to retry.
5. Android: export an invoice PDF, open it and check contents are not blank.
6. iPhone: test PDF saving and sharing, JSON backup, restore and offline persistence with test-only data.
7. Both: compare records before and after closing/reopening the native app.

Source checks are not substitutes for these tests.
