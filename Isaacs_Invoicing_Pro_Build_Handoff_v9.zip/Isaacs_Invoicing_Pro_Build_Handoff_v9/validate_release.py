#!/usr/bin/env python3
"""Offline source checks only; not a replacement for device tests."""
from pathlib import Path
import json,re,subprocess,sys
root=Path(__file__).resolve().parent
htmls=[root/'iOS/IsaacsInvoicingPro/Resources/index.html',root/'Android/app/src/main/assets/index.html']
checks=[]
for name,p in zip(('iOS','Android'),htmls):
    html=p.read_text()
    match=re.search(r'<script id="embeddedPortableBackup" type="application/json">(.*?)</script>',html,re.S)
    assert match, f'{name}: missing embedded backup'
    payload=json.loads(match.group(1)); data=payload['data']
    for key in ('customers','inventory','invoices','payments','credits','expenses','stockMovements'):
        assert data[key]==[], f'{name}: unexpected bundled {key}'
    assert data['settings']['currency']=='ZAR'
    scripts=re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>',html,re.S)
    for idx,script in enumerate(scripts):
        if not script.strip() or script.lstrip().startswith('{"format"'): continue
        check=subprocess.run(['node','--check','--input-type=commonjs'],input=script,text=True,capture_output=True)
        assert check.returncode==0,f'{name} script {idx}: {check.stderr}'
    checks.append(f'{name}: clean embedded data and JavaScript syntax')
android=htmls[1].read_text(); ios=(root/'iOS/IsaacsInvoicingPro/ContentView.swift').read_text()
kt=(root/'Android/app/src/main/java/za/co/isaacselectronics/invoicingpro/MainActivity.kt').read_text()
assert 'HTMLAnchorElement.prototype.click' in android and 'IsaacsAndroid.saveBase64' in android
assert 'HTMLAnchorElement.prototype.click' in ios and 'isaacsExport.postMessage' in ios
assert 'encoded.length > 28_000_000' in kt and 'ACTION_CREATE_DOCUMENT' in kt
checks.append('Export bridges and Android pre-decode size guard present')
assert re.search(r'<script id="embeddedPortableBackup"[^>]*>(.*?)</script>',htmls[0].read_text(),re.S).group(1) == re.search(r'<script id="embeddedPortableBackup"[^>]*>(.*?)</script>',android,re.S).group(1), 'Embedded source snapshot differs'
checks.append('Clean embedded snapshot matches across platforms')
print(json.dumps({'status':'PASS','checks':checks,'limitations':'No compilation, emulator, physical device, PDF, persistence, or store validation performed'},indent=2))
