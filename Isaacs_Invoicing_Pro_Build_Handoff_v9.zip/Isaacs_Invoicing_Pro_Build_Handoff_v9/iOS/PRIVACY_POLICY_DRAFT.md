# Privacy Policy — Isaac’s Invoicing Pro (DRAFT)

**Not for publication until the packaged app's actual behavior is verified.**

Isaac’s Invoicing Pro is designed to help users manage business customers, invoices, payments, inventory and reports. Information entered may include customer names, contact information, addresses, transaction amounts and business records.

The current prototype uses local browser storage and provides backup/export features. A final iOS application must be evaluated separately to confirm exactly where data is stored, whether any data leaves the device, and how exported files are handled. Users control where they save or share exported documents, which may contain personal information.

Before publishing this policy, confirm whether the released app uses cloud synchronization, analytics, crash reporting, third-party SDKs, account registration or remote services. Add the verified data retention, deletion, security, contact and user-rights procedures. Do not promise that no data is collected until these checks are complete.

Publisher contact: **isaacselectro@hotmail.com**
Effective date: **TO BE SET AT PUBLICATION**
Privacy policy URL: **TO BE PROVIDED**
