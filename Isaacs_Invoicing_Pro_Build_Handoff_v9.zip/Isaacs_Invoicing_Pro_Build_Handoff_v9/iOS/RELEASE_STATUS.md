# iOS release status — v4
- Bundled clean customer HTML: included.
- Native print bridge: source implemented; compilation and device testing pending.
- Native Blob download-to-share bridge: source implemented; compilation and device testing pending.
- navigator.share and all PDF export paths: not fully integrated.
- Commercial-grade persistent data and backup restoration: pending.
- App Store enrollment, signing, screenshot capture, review and publication: pending.
- Support contact: isaacselectro@hotmail.com.
- Proposed paid upfront price: R149.99 subject to Apple's tiers.
