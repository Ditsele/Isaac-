import SwiftUI
import WebKit
import UIKit

struct ContentView: View {
    var body: some View { InvoicingWebView().ignoresSafeArea(edges: .bottom) }
}

struct InvoicingWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let controller = WKUserContentController()
        controller.add(context.coordinator, name: "isaacsExport")
        controller.add(context.coordinator, name: "isaacsPrint")
        // Runs only in the app's bundled document. Blob downloads and print are
        // handed to native iOS rather than silently failing inside WKWebView.
        controller.addUserScript(WKUserScript(source: Self.bridgeJS,
            injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.userContentController = controller
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = context.coordinator
        view.uiDelegate = context.coordinator
        view.isOpaque = false
        view.backgroundColor = .systemBackground
        context.coordinator.webView = view
        if let file = Bundle.main.url(forResource: "index", withExtension: "html") {
            view.loadFileURL(file, allowingReadAccessTo: file.deletingLastPathComponent())
        }
        return view
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}

    // Clicks on downloadable Blob links are intercepted. The app's existing
    // JavaScript backup/export generators remain the source of file contents.
    private static let bridgeJS = #"""
    (function () {
      if (!window.webkit || !window.webkit.messageHandlers) return;
      const bridge = window.webkit.messageHandlers;
      window.print = function () { bridge.isaacsPrint.postMessage({}); };
      // The HTML application triggers downloads with anchor.click(), not a
      // physical click. Intercept both paths at the prototype method.
      const originalClick = HTMLAnchorElement.prototype.click;
      let preparing = false;
      HTMLAnchorElement.prototype.click = function () {
        const anchor = this;
        if (!anchor.download || !anchor.href || !anchor.href.startsWith('blob:')) {
          return originalClick.call(anchor);
        }
        if (preparing) { alert('Wait for the previous export to finish preparing.'); return; }
        preparing = true;
        fetch(anchor.href).then(function (response) {
          if (!response.ok) throw new Error('Cannot read export');
          return response.blob();
        }).then(function (blob) {
          if (blob.size > 20 * 1024 * 1024) throw new Error('Export exceeds 20 MB');
          return new Promise(function (resolve, reject) {
            const reader = new FileReader();
            reader.onerror = function () { reject(new Error('Cannot read export')); };
            reader.onload = function () { resolve({data: String(reader.result || ''), blob: blob}); };
            reader.readAsDataURL(blob);
          });
        }).then(function (result) {
          const comma = result.data.indexOf(',');
          if (comma < 0) throw new Error('Invalid export data');
          bridge.isaacsExport.postMessage({
            filename: anchor.download || 'export.dat',
            mime: result.blob.type || 'application/octet-stream',
            base64: result.data.slice(comma + 1)
          });
        }).catch(function (error) {
          alert('Export could not be prepared: ' + error.message);
        }).finally(function () { preparing = false; });
      };
    })();
    """#

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        weak var webView: WKWebView?
        private var exportInProgress = false

        func userContentController(_ userContentController: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard let webView = webView else { return }
            if message.name == "isaacsPrint" {
                let controller = UIPrintInteractionController.shared
                controller.printFormatter = webView.viewPrintFormatter()
                controller.present(animated: true, completionHandler: nil)
                return
            }
            guard message.name == "isaacsExport", !exportInProgress,
                  let info = message.body as? [String: String],
                  let encoded = info["base64"],
                  encoded.count < 28_000_000,
                  let bytes = Data(base64Encoded: encoded),
                  bytes.count <= 20_000_000 else { return }
            let requested = info["filename"] ?? "export.dat"
            let safeName = String(requested.map { char in
                char.isLetter || char.isNumber || "._- ".contains(char) ? char : "_"
            }).prefix(120)
            let filename = safeName.isEmpty ? "export.dat" : String(safeName)
            let folder = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString, isDirectory: true)
            do {
                try FileManager.default.createDirectory(at: folder,
                    withIntermediateDirectories: true)
                let file = folder.appendingPathComponent(filename)
                try bytes.write(to: file, options: .atomic)
                exportInProgress = true
                let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
                share.completionWithItemsHandler = { [weak self] _, _, _, _ in
                    self?.exportInProgress = false
                    // Do not delete immediately: Files may still be copying the item.
                }
                if let popover = share.popoverPresentationController {
                    popover.sourceView = webView
                    popover.sourceRect = CGRect(x: webView.bounds.midX,
                        y: webView.bounds.midY, width: 1, height: 1)
                }
                webView.window?.rootViewController?.present(share, animated: true)
            } catch { exportInProgress = false }
        }

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let url = navigationAction.request.url,
               !url.isFileURL && url.scheme != "about" && url.scheme != "data" &&
               url.scheme != "blob" {
                decisionHandler(.cancel)
            } else { decisionHandler(.allow) }
        }
    }
}
