import SwiftUI

@main
struct IsaacsInvoicingProApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
