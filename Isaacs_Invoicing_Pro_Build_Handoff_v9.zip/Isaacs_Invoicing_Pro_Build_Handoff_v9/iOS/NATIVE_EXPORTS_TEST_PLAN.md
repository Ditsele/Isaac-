# iPhone test plan (not yet executed)

1. Build and launch app on iPhone. Confirm clean starting data, currency selection and fast navigation.
2. Create a TEST customer, invoice and payment. Restart app; check balances and records persist.
3. Export JSON backup using the existing app flow; if a Blob download link is used, iOS share sheet should appear. Choose Save to Files and verify nonempty valid JSON.
4. Export CSV report, save to Files, open and inspect content.
5. Print invoice and receipt via app Print control; verify AirPrint preview contains full document, no blank pages.
6. Restore a TEST backup and confirm records. Never overwrite real records in tests.
7. Upgrade the app and verify storage retention; test recoverability after app reinstall (requires external backup).
8. Audit all export routes including navigator.share and direct PDF flows, since these are not all bridged yet.
