# App Store submission draft — Isaac’s Invoicing Pro Global 1.0

**Status:** preparation only; not submitted or approved.

- App name: Isaac’s Invoicing Pro
- Subtitle: Invoices, Payments & Stock
- Primary category: Business
- Proposed South Africa one-time purchase price: R149.99 (choose supported price point in App Store Connect)
- Brand: Isaac’s Electronics (currently deregistered; do not claim it is the registered Apple seller)
- Legal seller: to be determined at enrollment; individual enrollment normally displays legal personal name
- Primary language: English
- Customer support email: isaacselectro@hotmail.com (user-confirmed)

## Promotional text
Create invoices, record payments, manage stock and review business reports from your iPhone.

## Description
Isaac’s Invoicing Pro helps technicians, service providers and small businesses organize everyday invoicing. Create customer records and invoices, record payments, review outstanding balances, track inventory and reorder needs, and generate business reports. Choose an accounting currency for a new business record set.

Features available in the source include invoices, payments, customer statements, credit notes, expenses, inventory, purchasing status, reports and backup/export tools. Features must be verified in the packaged iOS build before these claims are finalized.

## Keywords (draft)
invoice,invoicing,receipt,payments,inventory,stock,business,technician,expenses

## Screenshots
Capture from the actual compiled iOS application, not a concept rendering. Suggested screens: Dashboard, Invoices, Payments, Inventory, Reports.

## Pre-submission blockers
- Verify compiled iOS build, persistence across updates, data export/import, file picker and native PDF sharing.
- Confirm legal seller identity and enrollment path; do not represent a deregistered company as active.
- Complete privacy questionnaire based on verified app behavior, including any future analytics or cloud services.
- Publish a working privacy policy URL and support contact/URL before submission.
- Produce 1024x1024 app icon without transparency and device-specific screenshots per current App Store Connect requirements.
- Confirm App Store price point, taxes, paid apps agreement, availability and age rating.
- Check App Review guidelines and avoid describing the app as already published.
