# Isaac’s Invoicing Pro — iOS Native Exports v4 (source)

This builds on the clean-customer iOS starter, retaining the same offline HTML application. `ContentView.swift` now implements native iOS print presentation for `window.print()` and intercepts downloadable Blob links to show the iOS share sheet (including Save to Files). It does **not** rewrite business records or add private customer data.

## Build
Requires Xcode on macOS or a compatible hosted macOS builder. Create a SwiftUI iOS app, copy both Swift files, add `Resources/index.html` to the app bundle, set your own bundle ID, icon, signing and deployment target. Build and test on iPhone. This ZIP is not an IPA or signed Xcode archive.

## Important limitations
- Some application exports call `navigator.share({files})` directly and may need additional adaptation. The bridge only intercepts `a[download]` Blob links and `window.print()`.
- WKWebView file input import and persistence must be validated on a real device; localStorage is **not** a sufficient long-term commercial storage guarantee.
- A printed PDF depends on the page's print CSS and native print formatting; verify invoice and receipt content.
- Native code has been reviewed statically, **not compiled or device-tested**.
- No store fees, enrollment or submissions have occurred. Support: isaacselectro@hotmail.com.
