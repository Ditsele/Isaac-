# Isaac’s Invoicing Pro — Cross-platform export results v8

This source package contains both iOS and Android development starters. Customer support: isaacselectro@hotmail.com. Proposed one-time price: R149.99, subject to store pricing.

## v8 change

Android now keeps the generated-file export guard active **until the Android system file picker returns**. The native code reports `saved`, `cancelled`, `error`, or `busy` back to the bundled HTML. A save is only reported as successful after the output stream is written and closed. This prevents overlapping file-picker requests from rapid repeated taps. It does **not** guarantee that a user has independently opened and verified a saved file.

The iOS native export bridge remains as in v7. No original working HTML or business records have been modified.

## Required next milestone

Compile and run Android in Android Studio and iOS in Xcode/macOS or an appropriate hosted build service. Test exports by saving a JSON backup, reopening it from Files, verifying content, cancelling a save, rapidly tapping export twice, and checking that subsequent exports still work. Test invoice PDF and restore using test-only data. Store approval and production builds are not yet complete.
