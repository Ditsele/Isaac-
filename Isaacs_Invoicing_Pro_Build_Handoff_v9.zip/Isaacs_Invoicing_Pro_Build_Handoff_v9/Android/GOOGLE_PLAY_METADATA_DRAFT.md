# Google Play listing — draft, not published

App title: Isaac’s Invoicing Pro
Developer brand: Isaac’s Electronics (legal account identity must be verified)
Support email: isaacselectro@hotmail.com
Category: Business
Proposed one-time purchase price: R149.99 in South Africa, subject to available Play Console pricing.

Short description (draft): Create invoices, record payments, track stock and view business reports.

Full description (draft): Isaac’s Invoicing Pro is an invoicing and stock management application for service providers and small businesses. It includes customer records, invoices, payment records, inventory, purchasing status, expenses and reports. Availability and reliability of features must be verified on a compiled Android build before publication.

Required before publication: verify actual app data practices, complete Google Play Data safety form, publish privacy policy URL, create store screenshots from real Android app, provide account/legal developer details, build and test signed AAB, confirm current policy and target SDK.
