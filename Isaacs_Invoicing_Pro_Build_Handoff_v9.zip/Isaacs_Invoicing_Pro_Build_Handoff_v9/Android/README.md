# Isaac's Invoicing Pro — Android Native Exports v3

Android Studio source starter with bundled clean Global 1.0 HTML. No APK/AAB is included.

## New engineering changes
- Android PrintManager handles `window.print()` calls from bundled HTML.
- Generated blob downloads are converted to Base64 and sent to Android's ACTION_CREATE_DOCUMENT picker.
- File chooser accepts JSON backup imports.
- Navigation is restricted to the bundled HTML page. No Internet permission.
- No private customer records bundled.

## Known limitations
- Not compiled or tested on device. PDF/print output and all exports must be verified.
- Native export bridge caps files at 20 MB; very large Base64 strings may hit WebView limits.
- localStorage is app-local, not cross-platform; backup/restore testing is essential.
- Android security, WebView file access, app signing, Google Play policy and billing must be validated.
- Build with Android Studio/Java 17, SDK 35 and installed Android Gradle Plugin dependencies.

Support: isaacselectro@hotmail.com. Proposed one-time price: R149.99.
See NATIVE_EXPORTS_TEST_PLAN.md and RELEASE_STATUS.md.
