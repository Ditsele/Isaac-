plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "za.co.isaacselectronics.invoicingpro"
 compileSdk = 35
 defaultConfig { applicationId = "za.co.isaacselectronics.invoicingpro"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
 buildTypes { release { isMinifyEnabled = false } }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
