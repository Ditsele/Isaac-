package za.co.isaacselectronics.invoicingpro

import android.app.Activity
import android.content.Intent
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingExport: ByteArray? = null
    private val chooserRequest = 1101
    private val exportRequest = 1102

    private fun reportExportResult(message: String) {
        // Only report completion after Android has written to the selected URI.
        web.evaluateJavascript("window.dispatchEvent(new CustomEvent(\"isaacs-native-export-result\", {detail: " + org.json.JSONObject.quote(message) + "}));", null)
    }

    inner class NativeExports {
        @JavascriptInterface
        fun saveBase64(filename: String, mime: String, encoded: String) {
            // Called from WebView's JS thread; launch Android UI on the main thread.
            // Reject oversized input before decoding, avoiding an unbounded allocation
            // from the JavaScript bridge. 20 MiB becomes ~28 MiB Base64.
            val bytes = if (encoded.length > 28_000_000) null else
                try { Base64.decode(encoded, Base64.DEFAULT) } catch (e: Exception) { null }
            runOnUiThread {
                if (bytes == null || bytes.size > 20 * 1024 * 1024) {
                    Toast.makeText(this@MainActivity, "Export unavailable or too large", Toast.LENGTH_LONG).show()
                    reportExportResult("error")
                    return@runOnUiThread
                }
                if (pendingExport != null) {
                    Toast.makeText(this@MainActivity, "Finish saving the previous export first", Toast.LENGTH_LONG).show()
                    reportExportResult("busy")
                    return@runOnUiThread
                }
                pendingExport = bytes
                val safeName = filename.replace(Regex("[^a-zA-Z0-9._ -]"), "_").take(120).ifBlank { "export.dat" }
                try {
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mime.takeIf { it.contains('/') } ?: "application/octet-stream"
                        putExtra(Intent.EXTRA_TITLE, safeName)
                    }, exportRequest)
                } catch (e: Exception) {
                    pendingExport = null
                    Toast.makeText(this@MainActivity, "Cannot open document saver", Toast.LENGTH_LONG).show()
                    reportExportResult("error")
                }
            }
        }

        @JavascriptInterface
        fun printDocument() {
            runOnUiThread {
                try {
                    val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    manager.print("Isaacs Invoicing Pro", web.createPrintDocumentAdapter("Isaacs Invoicing Pro"), PrintAttributes.Builder().build())
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Printing unavailable", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true // Bundled offline HTML only
        web.settings.allowContentAccess = true // Android file chooser
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.addJavascriptInterface(NativeExports(), "IsaacsAndroid")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                return uri.scheme != "file" || uri.toString() != "file:///android_asset/index.html"
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    startActivityForResult(params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }, chooserRequest)
                    true
                } catch (e: Exception) { fileCallback = null; callback?.onReceiveValue(null); false }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Activity result compatibility for starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == chooserRequest) {
            fileCallback?.onReceiveValue(if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null)
            fileCallback = null
        } else if (requestCode == exportRequest) {
            val bytes = pendingExport
            pendingExport = null
            if (resultCode == RESULT_OK && bytes != null && data?.data != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { it.write(bytes) }
                        ?: throw IOException("Cannot open selected file")
                    Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show()
                    reportExportResult("saved")
                } catch (e: Exception) {
                    Toast.makeText(this, "File save failed", Toast.LENGTH_LONG).show()
                    reportExportResult("error")
                }
            } else if (resultCode != RESULT_OK) {
                reportExportResult("cancelled")
            }
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    override fun onDestroy() {
        web.removeJavascriptInterface("IsaacsAndroid")
        web.destroy()
        super.onDestroy()
    }
}
