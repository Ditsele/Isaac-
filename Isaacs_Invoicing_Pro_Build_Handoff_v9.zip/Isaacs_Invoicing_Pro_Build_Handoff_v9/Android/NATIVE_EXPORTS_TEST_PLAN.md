# Android native exports test plan — unverified on device

1. Install a debug build on Android and open the offline app; confirm customer and invoice navigation works rapidly.
2. Create a test customer, invoice, payment and check the remaining balance.
3. Export JSON backup; Android system Create Document picker must appear, save the file, open it, verify JSON.
4. Export CSV and TXT reports; verify correct filename and contents.
5. Print invoice and receipt; Android print UI must open and allow Save as PDF. Check the resulting PDF is not blank.
6. Restore the JSON backup using the file chooser after preserving an independent backup.
7. Force close/reopen; verify data persists. Update app without clearing app data; verify records persist.
8. Cancel save and print dialogs; ensure no unintended data changes.
9. Test large exports, repeated taps, unsupported mime types, and Android 8 through current supported OS.
10. Confirm privacy, offline functionality, Play compliance and signed release build.

WARNING: The HTML app uses localStorage; it is NOT a secure transactional database or guaranteed backup. Device deletion/clear data removes local records. Test before release.
