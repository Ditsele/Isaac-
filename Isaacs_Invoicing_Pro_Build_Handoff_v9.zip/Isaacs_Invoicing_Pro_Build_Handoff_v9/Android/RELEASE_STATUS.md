# Release status — Android Native Exports v3

**Implemented in source, not built/tested:** Android document picker for generated blob exports (JSON/CSV/TXT/PDF), Android PrintManager bridge for window.print(), HTML file chooser, offline WebView and localStorage.

**Not yet verified:** native build, actual PDF layout, data restore, cross-device persistence, Android UI speed, store compliance, signed APK/AAB.

**Important:** iOS source remains unchanged. Original user business records are not bundled.

**Contact:** isaacselectro@hotmail.com
**Proposed price:** R149.99 one-time, not configured.
