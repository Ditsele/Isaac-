# Isaac's Invoicing Pro — native build handoff v9

**Status:** Source only. Neither app has been compiled or device-tested in this environment.
**Support:** isaacselectro@hotmail.com
**Commercial plan:** Proposed R149.99 one-time purchase, subject to each store's price tiers.

## Android — compile on a computer or cloud build machine
1. Install Android Studio with Android SDK 35 and JDK 17.
2. Open the `Android` directory as a Gradle project.
3. Allow Android Studio to download Gradle and Android Gradle Plugin dependencies. The Gradle wrapper is not included.
4. Build a debug APK via Build > Build APK(s). Install it on a test Android device.
5. Check invoice preview, PDF print/save, JSON export, cancellation, and backup import using disposable test records.
6. Only after device tests pass, create a signed AAB and complete Play Console listing, privacy and account requirements.

## iOS — compile on macOS or hosted macOS build
1. Install Xcode and XcodeGen (`brew install xcodegen`).
2. In the `iOS` directory run `xcodegen generate`.
3. Open the generated `IsaacsInvoicingPro.xcodeproj` in Xcode.
4. Choose your own development signing team and test on a simulator and an iPhone.
5. Test local data persistence after app restart, JSON backup and restore, PDF print/save, file sharing and external links.
6. Create a release archive only after these tests pass. Store submission requires an eligible developer account.

## Release blockers
- Actual compilation and device testing on both platforms.
- Test backup restore and cross-version data migration without touching production records.
- Verify PDF and receipt output are not blank and saved files reopen.
- Confirm privacy declarations and publish a valid privacy policy/support URL.
- Produce genuine device screenshots, app icon, and complete store metadata.
- Confirm current store enrollment and price-tier requirements before paying.

## Safety
The bundled HTML is the clean release copy. Do not overwrite the original working iPhone HTML or its JSON backups.
The source project does not include a signed APK, AAB, or IPA.
